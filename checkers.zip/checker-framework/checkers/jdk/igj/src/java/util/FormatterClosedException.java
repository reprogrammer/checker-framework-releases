package java.util;

public class FormatterClosedException extends IllegalStateException {
    private static final long serialVersionUID = 0L;
  public FormatterClosedException() { throw new RuntimeException("skeleton method"); }
}
