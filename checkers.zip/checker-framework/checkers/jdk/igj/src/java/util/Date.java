package java.util;
import checkers.igj.quals.*;

@I
public class Date implements @I java.io.Serializable, @I Cloneable, @I Comparable<@ReadOnly Date> {
    private static final long serialVersionUID = 0L;
  public Date(@AssignsFields Date this) { throw new RuntimeException("skeleton method"); }
  public Date(@AssignsFields Date this, long a1) { throw new RuntimeException("skeleton method"); }
  public Date(@AssignsFields Date this, int a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public Date(@AssignsFields Date this, int a1, int a2, int a3, int a4, int a5) { throw new RuntimeException("skeleton method"); }
  public Date(@AssignsFields Date this, int a1, int a2, int a3, int a4, int a5, int a6) { throw new RuntimeException("skeleton method"); }
  public Date(@AssignsFields Date this, String a1) { throw new RuntimeException("skeleton method"); }
  public static long UTC(int a1, int a2, int a3, int a4, int a5, int a6) { throw new RuntimeException("skeleton method"); }
  public static long parse(String a1) { throw new RuntimeException("skeleton method"); }
  public int getYear(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public void setYear(@AssignsFields Date this, int a1) { throw new RuntimeException("skeleton method"); }
  public int getMonth(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public void setMonth(@AssignsFields Date this, int a1) { throw new RuntimeException("skeleton method"); }
  public int getDate(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public void setDate(@AssignsFields Date this, int a1) { throw new RuntimeException("skeleton method"); }
  public int getDay(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public int getHours(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public void setHours(@AssignsFields Date this, int a1) { throw new RuntimeException("skeleton method"); }
  public int getMinutes(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public void setMinutes(@AssignsFields Date this, int a1) { throw new RuntimeException("skeleton method"); }
  public int getSeconds(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public void setSeconds(@AssignsFields Date this, int a1) { throw new RuntimeException("skeleton method"); }
  public long getTime(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public void setTime(@AssignsFields Date this, long a1) { throw new RuntimeException("skeleton method"); }
  public boolean before(@ReadOnly Date this, @ReadOnly Date a1) { throw new RuntimeException("skeleton method"); }
  public boolean after(@ReadOnly Date this, @ReadOnly Date a1) { throw new RuntimeException("skeleton method"); }
  public boolean equals(@ReadOnly Date this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public int compareTo(@ReadOnly Date this, @ReadOnly Date a1) { throw new RuntimeException("skeleton method"); }
  public int hashCode(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public String toString(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public String toLocaleString(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public String toGMTString(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public int getTimezoneOffset(@ReadOnly Date this) { throw new RuntimeException("skeleton method"); }
  public @I("N") Object clone() { throw new RuntimeException("skeleton method"); }
}
