package java.util;
import checkers.igj.quals.*;

@I
public class HashSet<E> extends @I AbstractSet<E> implements @I Set<E>, @I Cloneable, java.io. @I Serializable {
    private static final long serialVersionUID = 0L;
  public HashSet(@AssignsFields HashSet<E> this) { throw new RuntimeException("skeleton method"); }
  public HashSet(@AssignsFields HashSet<E> this, @ReadOnly Collection<? extends E> a1) { throw new RuntimeException("skeleton method"); }
  public HashSet(@AssignsFields HashSet<E> this, int a1, float a2) { throw new RuntimeException("skeleton method"); }
  public HashSet(@AssignsFields HashSet<E> this, int a1) { throw new RuntimeException("skeleton method"); }
  public @I Iterator<E> iterator(@ReadOnly HashSet<E> this) { throw new RuntimeException("skeleton method"); }
  public int size(@ReadOnly HashSet<E> this) { throw new RuntimeException("skeleton method"); }
  public boolean isEmpty(@ReadOnly HashSet<E> this) { throw new RuntimeException("skeleton method"); }
  public boolean contains(@ReadOnly HashSet<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public boolean add(@Mutable HashSet<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public boolean remove(@Mutable HashSet<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public void clear(@Mutable HashSet<E> this) { throw new RuntimeException("skeleton method"); }
  public @I("N") Object clone() { throw new RuntimeException("skeleton method"); }
}
