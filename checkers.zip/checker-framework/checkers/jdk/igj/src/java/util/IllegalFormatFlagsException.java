package java.util;

public class IllegalFormatFlagsException extends IllegalFormatException {
    private static final long serialVersionUID = 0L;
  public IllegalFormatFlagsException(String a1) { throw new RuntimeException("skeleton method"); }
  public String getFlags() { throw new RuntimeException("skeleton method"); }
  public String getMessage() { throw new RuntimeException("skeleton method"); }
}
