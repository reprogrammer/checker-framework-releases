package java.util;
import checkers.igj.quals.*;

@I
public class BitSet implements @I Cloneable, java.io. @I Serializable {
    private static final long serialVersionUID = 0L;
  public BitSet(@AssignsFields BitSet this) { throw new RuntimeException("skeleton method"); }
  public BitSet(@AssignsFields BitSet this, int a1) { throw new RuntimeException("skeleton method"); }
  public void flip(@Mutable BitSet this, int a1) { throw new RuntimeException("skeleton method"); }
  public void flip(@Mutable BitSet this, int a1, int a2) { throw new RuntimeException("skeleton method"); }
  public void set(@AssignsFields BitSet this, int a1) { throw new RuntimeException("skeleton method"); }
  public void set(@AssignsFields BitSet this, int a1, boolean a2) { throw new RuntimeException("skeleton method"); }
  public void set(@AssignsFields BitSet this, int a1, int a2) { throw new RuntimeException("skeleton method"); }
  public void set(@AssignsFields BitSet this, int a1, int a2, boolean a3) { throw new RuntimeException("skeleton method"); }
  public void clear(@AssignsFields BitSet this, int a1)  { throw new RuntimeException("skeleton method"); }
  public void clear(@AssignsFields BitSet this, int a1, int a2)  { throw new RuntimeException("skeleton method"); }
  public void clear(@AssignsFields BitSet this) { throw new RuntimeException("skeleton method"); }
  public boolean get(@ReadOnly BitSet this, int a1) { throw new RuntimeException("skeleton method"); }
  public @I("T") BitSet get(@ReadOnly BitSet this, int a1, int a2) { throw new RuntimeException("skeleton method"); }
  public int nextSetBit(@ReadOnly BitSet this, int a1) { throw new RuntimeException("skeleton method"); }
  public int nextClearBit(@ReadOnly BitSet this, int a1) { throw new RuntimeException("skeleton method"); }
  public int length(@ReadOnly BitSet this) { throw new RuntimeException("skeleton method"); }
  public boolean isEmpty(@ReadOnly BitSet this) { throw new RuntimeException("skeleton method"); }
  public boolean intersects(@ReadOnly BitSet this, @ReadOnly BitSet a1) { throw new RuntimeException("skeleton method"); }
  public int cardinality(@ReadOnly BitSet this) { throw new RuntimeException("skeleton method"); }
  public void and(@Mutable BitSet this, @ReadOnly BitSet a1) { throw new RuntimeException("skeleton method"); }
  public void or(@Mutable BitSet this, @ReadOnly BitSet a1) { throw new RuntimeException("skeleton method"); }
  public void xor(@Mutable BitSet this, @ReadOnly BitSet a1) { throw new RuntimeException("skeleton method"); }
  public void andNot(@Mutable BitSet this, @ReadOnly BitSet a1) { throw new RuntimeException("skeleton method"); }
  public int hashCode(@ReadOnly BitSet this) { throw new RuntimeException("skeleton method"); }
  public int size(@ReadOnly BitSet this) { throw new RuntimeException("skeleton method"); }
  public boolean equals(@ReadOnly BitSet this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public String toString(@ReadOnly BitSet this) { throw new RuntimeException("skeleton method"); }
  public Object clone(@ReadOnly BitSet this) { throw new RuntimeException("skeleton method"); }
}
