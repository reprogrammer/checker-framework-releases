package java.util;
import checkers.igj.quals.*;

@I
public class Hashtable<K, V> extends @I Dictionary<K, V> implements @I Map<K, V>, @I Cloneable, java.io. @I Serializable {
    private static final long serialVersionUID = 0L;
  public Hashtable(@AssignsFields Hashtable<K, V> this, int a1, float a2) { throw new RuntimeException("skeleton method"); }
  public Hashtable(@AssignsFields Hashtable<K, V> this, int a1) { throw new RuntimeException("skeleton method"); }
  public Hashtable(@AssignsFields Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public Hashtable(@AssignsFields Hashtable<K, V> this, @ReadOnly Map<? extends K, ? extends V> a1) { throw new RuntimeException("skeleton method"); }
  public synchronized int size(@ReadOnly Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public synchronized boolean isEmpty(@ReadOnly Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public synchronized Enumeration<K> keys(@ReadOnly Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public synchronized Enumeration<V> elements(@ReadOnly Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public synchronized boolean contains(@ReadOnly Hashtable<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public boolean containsValue(@ReadOnly Hashtable<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public synchronized boolean containsKey(@ReadOnly Hashtable<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public synchronized V get(@ReadOnly Hashtable<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public synchronized V put(@Mutable Hashtable<K, V> this, K a1, V a2) { throw new RuntimeException("skeleton method"); }
  public synchronized V remove(@Mutable Hashtable<K, V> this, Object a1) { throw new RuntimeException("skeleton method"); }
  public synchronized void putAll(@Mutable Hashtable<K, V> this, @ReadOnly Map<? extends K, ? extends V> a1) { throw new RuntimeException("skeleton method"); }
  public synchronized void clear(@AssignsFields Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public synchronized String toString(@ReadOnly Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I Set<K> keySet(@ReadOnly Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I Set<@I Map.Entry<K, V>> entrySet(@ReadOnly Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I Collection<V> values(@ReadOnly Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public synchronized boolean equals(@ReadOnly Hashtable<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public synchronized int hashCode(@ReadOnly Hashtable<K, V> this) { throw new RuntimeException("skeleton method"); }
  public synchronized @I("N") Object clone() { throw new RuntimeException("skeleton method"); }
}
