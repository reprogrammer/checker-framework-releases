package java.util;
import checkers.igj.quals.*;

@I
public class ArrayDeque<E> extends @I AbstractCollection<E> implements @I Deque<E>, @I Cloneable, @I java.io.Serializable {
    private static final long serialVersionUID = 0L;
  public ArrayDeque(@AssignsFields ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public ArrayDeque(@AssignsFields ArrayDeque<E> this, int a1) { throw new RuntimeException("skeleton method"); }
  public ArrayDeque(@AssignsFields ArrayDeque<E> this, @ReadOnly Collection<? extends E> a1) { throw new RuntimeException("skeleton method"); }
  public void addFirst(@Mutable ArrayDeque<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public void addLast(@Mutable ArrayDeque<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public boolean offerFirst(@Mutable ArrayDeque<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public boolean offerLast(@Mutable ArrayDeque<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public E removeFirst(@Mutable ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public E removeLast(@Mutable ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public E pollFirst(@Mutable ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public E pollLast(@Mutable ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public E getFirst(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public E getLast(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public E peekFirst(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public E peekLast(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public boolean removeFirstOccurrence(@Mutable ArrayDeque<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public boolean removeLastOccurrence(@Mutable ArrayDeque<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public boolean add(@Mutable ArrayDeque<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public boolean offer(@Mutable ArrayDeque<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public E remove(@Mutable ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public E poll(@Mutable ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public E element(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public E peek(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public void push(@Mutable ArrayDeque<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public E pop(@Mutable ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public int size(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public boolean isEmpty(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public @I Iterator<E> iterator(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public @I Iterator<E> descendingIterator(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public boolean contains(@ReadOnly ArrayDeque<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public boolean remove(@Mutable ArrayDeque<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public void clear(@Mutable ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public Object[] toArray(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException("skeleton method"); }
  public <T> T[] toArray(@ReadOnly ArrayDeque<E> this, T[] a1) { throw new RuntimeException("skeleton method"); }
  public @I("N") ArrayDeque<E> clone() { throw new RuntimeException("skeleton method"); }
}
