package java.util;
import checkers.igj.quals.*;

@I
public class ArrayList<E> extends @I AbstractList<E> implements @I List<E>, @I RandomAccess, @I Cloneable, @I java.io.Serializable {
    private static final long serialVersionUID = 0L;
  public ArrayList(@AssignsFields ArrayList<E> this, int a1) { throw new RuntimeException("skeleton method"); }
  public ArrayList(@AssignsFields ArrayList<E> this) { throw new RuntimeException("skeleton method"); }
  public ArrayList(@AssignsFields ArrayList<E> this, @ReadOnly Collection<? extends E> a1) { throw new RuntimeException("skeleton method"); }
  public void trimToSize(@AssignsFields ArrayList<E> this) { throw new RuntimeException("skeleton method"); }
  public void ensureCapacity(@AssignsFields ArrayList<E> this, int a1) { throw new RuntimeException("skeleton method"); }
  public int size(@ReadOnly ArrayList<E> this) { throw new RuntimeException("skeleton method"); }
  public boolean isEmpty(@ReadOnly ArrayList<E> this) { throw new RuntimeException("skeleton method"); }
  public boolean contains(@ReadOnly ArrayList<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public int indexOf(@ReadOnly ArrayList<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public int lastIndexOf(@ReadOnly ArrayList<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public Object[] toArray(@ReadOnly ArrayList<E> this) { throw new RuntimeException("skeleton method"); }
  public <T> T[] toArray(@ReadOnly ArrayList<E> this, T[] a1) { throw new RuntimeException("skeleton method"); }
  public E get(@ReadOnly ArrayList<E> this, int a1) { throw new RuntimeException("skeleton method"); }
  public E set(@Mutable ArrayList<E> this, int a1, E a2) { throw new RuntimeException("skeleton method"); }
  public boolean add(@Mutable ArrayList<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public void add(@Mutable ArrayList<E> this, int a1, E a2) { throw new RuntimeException("skeleton method"); }
  public E remove(@Mutable ArrayList<E> this, int a1) { throw new RuntimeException("skeleton method"); }
  public boolean remove(@Mutable ArrayList<E> this, Object a1) { throw new RuntimeException("skeleton method"); }
  public void clear(@Mutable ArrayList<E> this) { throw new RuntimeException("skeleton method"); }
  public boolean addAll(@Mutable ArrayList<E> this, @ReadOnly Collection<? extends E> a1) { throw new RuntimeException("skeleton method"); }
  public boolean addAll(@Mutable ArrayList<E> this, int a1, @ReadOnly Collection<? extends E> a2) { throw new RuntimeException("skeleton method"); }
  public @I("N") Object clone() { throw new RuntimeException("skeleton method"); }
}
