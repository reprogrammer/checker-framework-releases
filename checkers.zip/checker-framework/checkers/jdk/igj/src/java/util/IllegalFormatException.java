package java.util;

public class IllegalFormatException extends IllegalArgumentException {
    private static final long serialVersionUID = 0L;
  protected IllegalFormatException() {}
}
