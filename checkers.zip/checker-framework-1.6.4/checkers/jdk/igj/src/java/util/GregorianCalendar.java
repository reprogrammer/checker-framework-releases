package java.util;
import checkers.igj.quals.*;

@I
public class GregorianCalendar extends @I Calendar{
    private static final long serialVersionUID = 0L;
  public final static int BC = 0;
  public final static int AD = 1;
  public GregorianCalendar()  { throw new RuntimeException("skeleton method"); }
  public GregorianCalendar(@ReadOnly TimeZone a1) { throw new RuntimeException("skeleton method"); }
  public GregorianCalendar(@ReadOnly Locale a1) { throw new RuntimeException("skeleton method"); }
  public GregorianCalendar(@ReadOnly TimeZone a1, @ReadOnly Locale a2) { throw new RuntimeException("skeleton method"); }
  public GregorianCalendar(int a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public GregorianCalendar(int a1, int a2, int a3, int a4, int a5) { throw new RuntimeException("skeleton method"); }
  public GregorianCalendar(int a1, int a2, int a3, int a4, int a5, int a6) { throw new RuntimeException("skeleton method"); }
  public void setGregorianChange(@AssignsFields GregorianCalendar this, @ReadOnly Date a1) { throw new RuntimeException("skeleton method"); }
  public final Date getGregorianChange(@ReadOnly GregorianCalendar this) { throw new RuntimeException("skeleton method"); }
  public boolean isLeapYear(@ReadOnly GregorianCalendar this, int a1) { throw new RuntimeException("skeleton method"); }
  public boolean equals(@ReadOnly GregorianCalendar this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public int hashCode(@ReadOnly GregorianCalendar this) { throw new RuntimeException("skeleton method"); }
  public void add(@AssignsFields GregorianCalendar this, int a1, int a2) { throw new RuntimeException("skeleton method"); }
  public void roll(@AssignsFields GregorianCalendar this, int a1, boolean a2) { throw new RuntimeException("skeleton method"); }
  public void roll(@AssignsFields GregorianCalendar this, int a1, int a2) { throw new RuntimeException("skeleton method"); }
  public int getMinimum(@ReadOnly GregorianCalendar this, int a1) { throw new RuntimeException("skeleton method"); }
  public int getMaximum(@ReadOnly GregorianCalendar this, int a1) { throw new RuntimeException("skeleton method"); }
  public int getGreatestMinimum(@ReadOnly GregorianCalendar this, int a1) { throw new RuntimeException("skeleton method"); }
  public int getLeastMaximum(@ReadOnly GregorianCalendar this, int a1) { throw new RuntimeException("skeleton method"); }
  public int getActualMinimum(@ReadOnly GregorianCalendar this, int a1) { throw new RuntimeException("skeleton method"); }
  public int getActualMaximum(@ReadOnly GregorianCalendar this, int a1) { throw new RuntimeException("skeleton method"); }
  public @ReadOnly TimeZone getTimeZone(@ReadOnly GregorianCalendar this) { throw new RuntimeException("skeleton method"); }
  public void setTimeZone(@AssignsFields GregorianCalendar this, @ReadOnly TimeZone a1) { throw new RuntimeException("skeleton method"); }
  public @I("N") Object clone() { throw new RuntimeException("skeleton method"); }
}
