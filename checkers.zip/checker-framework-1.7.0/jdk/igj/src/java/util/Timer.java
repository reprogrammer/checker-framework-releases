package java.util;

import checkers.igj.quals.*;

@I
public class Timer{
  public Timer() { throw new RuntimeException("skeleton method"); }
  public Timer(boolean a1) { throw new RuntimeException("skeleton method"); }
  public Timer(String a1) { throw new RuntimeException("skeleton method"); }
  public Timer(String a1, boolean a2) { throw new RuntimeException("skeleton method"); }
  public void schedule(@AssignsFields Timer this, @Mutable TimerTask a1, long a2) { throw new RuntimeException("skeleton method"); }
  public void schedule(@AssignsFields Timer this, @Mutable TimerTask a1, @Immutable Date a2) { throw new RuntimeException("skeleton method"); }
  public void schedule(@AssignsFields Timer this, @Mutable TimerTask a1, long a2, long a3) { throw new RuntimeException("skeleton method"); }
  public void schedule(@AssignsFields Timer this, @Mutable TimerTask a1, @Immutable Date a2, long a3) { throw new RuntimeException("skeleton method"); }
  public void scheduleAtFixedRate(@AssignsFields Timer this, @Mutable TimerTask a1, long a2, long a3) { throw new RuntimeException("skeleton method"); }
  public void scheduleAtFixedRate(@AssignsFields Timer this, @Mutable TimerTask a1, Date a2, long a3) { throw new RuntimeException("skeleton method"); }
  public void cancel(@AssignsFields Timer this) { throw new RuntimeException("skeleton method"); }
  public int purge(@AssignsFields Timer this) { throw new RuntimeException("skeleton method"); }
}
