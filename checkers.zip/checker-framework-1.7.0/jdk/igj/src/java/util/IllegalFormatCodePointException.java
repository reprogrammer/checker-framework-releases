package java.util;

public class IllegalFormatCodePointException extends IllegalFormatException {
    private static final long serialVersionUID = 0L;
  public IllegalFormatCodePointException(int a1) { throw new RuntimeException("skeleton method"); }
  public int getCodePoint() { throw new RuntimeException("skeleton method"); }
  public String getMessage() { throw new RuntimeException("skeleton method"); }
}
