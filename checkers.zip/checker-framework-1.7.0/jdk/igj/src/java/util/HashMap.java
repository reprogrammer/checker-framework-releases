package java.util;
import checkers.igj.quals.*;

@I
public class HashMap<K, V> extends @I AbstractMap<K, V> implements @I Map<K, V>, @I Cloneable, java.io. @I Serializable {
    private static final long serialVersionUID = 0L;
  public HashMap(int a1, float a2) { throw new RuntimeException("skeleton method"); }
  public HashMap(int a1) { throw new RuntimeException("skeleton method"); }
  public HashMap() { throw new RuntimeException("skeleton method"); }
  public HashMap(@ReadOnly Map<? extends K, ? extends V> a1) { throw new RuntimeException("skeleton method"); }
  public int size(@ReadOnly HashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public boolean isEmpty(@ReadOnly HashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public V get(@ReadOnly HashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public boolean containsKey(@ReadOnly HashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public V put(@Mutable HashMap<K, V> this, K a1, V a2) { throw new RuntimeException("skeleton method"); }
  public void putAll(@Mutable HashMap<K, V> this, @ReadOnly Map<? extends K, ? extends V> a1) { throw new RuntimeException("skeleton method"); }
  public V remove(@Mutable HashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public void clear(@Mutable HashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public boolean containsValue(@ReadOnly HashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public @I Set<K> keySet(@ReadOnly HashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I Collection<V> values(@ReadOnly HashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I Set<Map. @I Entry<K, V>> entrySet(@ReadOnly HashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I("N") Object clone() { throw new RuntimeException("skeleton method"); }
}
