package java.util;

public class UnknownFormatConversionException extends IllegalFormatException {
    private static final long serialVersionUID = 0L;
  public UnknownFormatConversionException(String a1) { throw new RuntimeException("skeleton method"); }
  public String getConversion() { throw new RuntimeException("skeleton method"); }
  public String getMessage() { throw new RuntimeException("skeleton method"); }
}
