package java.util;

public class TooManyListenersException extends Exception {
    private static final long serialVersionUID = 0L;
  public TooManyListenersException() { throw new RuntimeException("skeleton method"); }
  public TooManyListenersException(String a1) { throw new RuntimeException("skeleton method"); }
}
