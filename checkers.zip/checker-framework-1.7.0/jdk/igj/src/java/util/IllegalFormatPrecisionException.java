package java.util;

public class IllegalFormatPrecisionException extends IllegalFormatException {
    private static final long serialVersionUID = 0L;
  public IllegalFormatPrecisionException(int a1) { throw new RuntimeException("skeleton method"); }
  public int getPrecision() { throw new RuntimeException("skeleton method"); }
  public String getMessage() { throw new RuntimeException("skeleton method"); }
}
