package java.util;

import checkers.igj.quals.*;

@I
public final class Scanner implements @Immutable Iterator<String> {
  public Scanner(Readable a1) { throw new RuntimeException("skeleton method"); }
  public Scanner(java.io.InputStream a1) { throw new RuntimeException("skeleton method"); }
  public Scanner(java.io.InputStream a1, String a2) { throw new RuntimeException("skeleton method"); }
  public Scanner(java.io.File a1) throws java.io.FileNotFoundException { throw new RuntimeException("skeleton method"); }
  public Scanner(java.io.File a1, String a2) throws java.io.FileNotFoundException { throw new RuntimeException("skeleton method"); }
  public Scanner(String a1) { throw new RuntimeException("skeleton method"); }
  public Scanner(java.nio.channels.ReadableByteChannel a1) { throw new RuntimeException("skeleton method"); }
  public Scanner(java.nio.channels.ReadableByteChannel a1, String a2) { throw new RuntimeException("skeleton method"); }
  public void close(@Mutable Scanner this) { throw new RuntimeException("skeleton method"); }
  public java.io.IOException ioException(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public java.util.regex.Pattern delimiter(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public @I Scanner useDelimiter(@Mutable Scanner this, java.util.regex.Pattern a1) { throw new RuntimeException("skeleton method"); }
  public @I Scanner useDelimiter(@Mutable Scanner this, String a1) { throw new RuntimeException("skeleton method"); }
  public Locale locale(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public @I Scanner useLocale(@ReadOnly Scanner this, Locale a1) { throw new RuntimeException("skeleton method"); }
  public int radix(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public @I Scanner useRadix(@AssignsFields Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public java.util.regex.MatchResult match(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public String toString(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean hasNext(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public String next(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public void remove(@Mutable Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean hasNext(@ReadOnly Scanner this, String a1) { throw new RuntimeException("skeleton method"); }
  public String next(@ReadOnly Scanner this, String a1) { throw new RuntimeException("skeleton method"); }
  public boolean hasNext(@ReadOnly Scanner this, java.util.regex.Pattern a1) { throw new RuntimeException("skeleton method"); }
  public String next(@ReadOnly Scanner this, java.util.regex.Pattern a1) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextLine(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public String nextLine(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public String findInLine(@ReadOnly Scanner this, String a1) { throw new RuntimeException("skeleton method"); }
  public String findInLine(@ReadOnly Scanner this, java.util.regex.Pattern a1) { throw new RuntimeException("skeleton method"); }
  public String findWithinHorizon(@ReadOnly Scanner this, String a1, int a2) { throw new RuntimeException("skeleton method"); }
  public String findWithinHorizon(@ReadOnly Scanner this, java.util.regex.Pattern a1, int a2) { throw new RuntimeException("skeleton method"); }
  public @I Scanner skip(@Mutable Scanner this, java.util.regex.Pattern a1) { throw new RuntimeException("skeleton method"); }
  public @I Scanner skip(@Mutable Scanner this, String a1) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextBoolean(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean nextBoolean(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextByte(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextByte(@ReadOnly Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public byte nextByte(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public byte nextByte(@ReadOnly Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextShort(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextShort(@ReadOnly Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public short nextShort(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public short nextShort(@ReadOnly Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextInt(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextInt(@ReadOnly Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public int nextInt(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public int nextInt(@ReadOnly Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextLong(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextLong(@ReadOnly Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public long nextLong(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public long nextLong(@ReadOnly Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextFloat(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public float nextFloat(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextDouble(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public double nextDouble(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextBigInteger(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextBigInteger(@ReadOnly Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public java.math.BigInteger nextBigInteger(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public java.math.BigInteger nextBigInteger(@ReadOnly Scanner this, int a1) { throw new RuntimeException("skeleton method"); }
  public boolean hasNextBigDecimal(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public java.math.BigDecimal nextBigDecimal(@ReadOnly Scanner this) { throw new RuntimeException("skeleton method"); }
  public @I Scanner reset(@Mutable Scanner this) { throw new RuntimeException("skeleton method"); }
}
