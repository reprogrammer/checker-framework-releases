package java.util;
import checkers.igj.quals.*;

@I
public class LinkedHashSet<E> extends @I HashSet<E> implements @I Set<E>, @I Cloneable, java.io. @I Serializable {
    private static final long serialVersionUID = 0L;
  public LinkedHashSet(int a1, float a2) { throw new RuntimeException("skeleton method"); }
  public LinkedHashSet(int a1) { throw new RuntimeException("skeleton method"); }
  public LinkedHashSet() { throw new RuntimeException("skeleton method"); }
  public LinkedHashSet(@ReadOnly Collection<? extends E> a1) { throw new RuntimeException("skeleton method"); }
}
