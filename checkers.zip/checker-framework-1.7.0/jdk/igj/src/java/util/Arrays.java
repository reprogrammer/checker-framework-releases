package java.util;
import checkers.igj.quals.*;

public class Arrays{
  protected Arrays() {}
  public static void sort(long @Mutable [] a1) { throw new RuntimeException("skeleton method"); }
  public static void sort(long @Mutable [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static void sort(int @Mutable [] a1) { throw new RuntimeException("skeleton method"); }
  public static void sort(int @Mutable [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static void sort(short @Mutable [] a1) { throw new RuntimeException("skeleton method"); }
  public static void sort(short @Mutable [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static void sort(char @Mutable [] a1) { throw new RuntimeException("skeleton method"); }
  public static void sort(char @Mutable [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static void sort(byte @Mutable [] a1) { throw new RuntimeException("skeleton method"); }
  public static void sort(byte @Mutable [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static void sort(double @Mutable [] a1) { throw new RuntimeException("skeleton method"); }
  public static void sort(double @Mutable [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static void sort(float @Mutable [] a1) { throw new RuntimeException("skeleton method"); }
  public static void sort(float @Mutable [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static void sort(@ReadOnly Object @Mutable [] a1) { throw new RuntimeException("skeleton method"); }
  public static void sort(@ReadOnly Object @Mutable [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static <T> void sort(T @Mutable [ ] a1, @ReadOnly Comparator<? super T> a2) { throw new RuntimeException("skeleton method"); }
  public static <T> void sort(T @Mutable [ ] a1, int a2, int a3, @ReadOnly Comparator<? super T> a4) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(long @ReadOnly [] a1, long a2) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(long @ReadOnly [] a1, int a2, int a3, long a4) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(int @ReadOnly [] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(int @ReadOnly [] a1, int a2, int a3, int a4) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(short @ReadOnly [] a1, short a2) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(short @ReadOnly [] a1, int a2, int a3, short a4) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(char @ReadOnly [] a1, char a2) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(char @ReadOnly [] a1, int a2, int a3, char a4) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(byte @ReadOnly [] a1, byte a2) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(byte @ReadOnly [] a1, int a2, int a3, byte a4) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(double @ReadOnly [] a1, double a2) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(double @ReadOnly [] a1, int a2, int a3, double a4) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(float @ReadOnly [] a1, float a2) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(float @ReadOnly [] a1, int a2, int a3, float a4) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(@ReadOnly Object @ReadOnly [] a1, @ReadOnly Object a2) { throw new RuntimeException("skeleton method"); }
  public static int binarySearch(@ReadOnly Object @ReadOnly [] a1, int a2, int a3, @ReadOnly Object a4) { throw new RuntimeException("skeleton method"); }
  public static <T> int binarySearch(@ReadOnly T @ReadOnly [] a1, T a2, @ReadOnly Comparator<? super T> a3) { throw new RuntimeException("skeleton method"); }
  public static <T> int binarySearch(@ReadOnly T @ReadOnly [] a1, int a2, int a3, T a4, @ReadOnly Comparator<? super T> a5) { throw new RuntimeException("skeleton method"); }
  public static boolean equals(long @ReadOnly [] a1, long @ReadOnly [] a2) { throw new RuntimeException("skeleton method"); }
  public static boolean equals(int @ReadOnly [] a1, int @ReadOnly [] a2) { throw new RuntimeException("skeleton method"); }
  public static boolean equals(short @ReadOnly [] a1, short @ReadOnly [] a2) { throw new RuntimeException("skeleton method"); }
  public static boolean equals(char @ReadOnly [] a1, char @ReadOnly [] a2) { throw new RuntimeException("skeleton method"); }
  public static boolean equals(byte @ReadOnly [] a1, byte @ReadOnly [] a2) { throw new RuntimeException("skeleton method"); }
  public static boolean equals(boolean @ReadOnly [] a1, boolean @ReadOnly [] a2) { throw new RuntimeException("skeleton method"); }
  public static boolean equals(double @ReadOnly [] a1, double @ReadOnly [] a2) { throw new RuntimeException("skeleton method"); }
  public static boolean equals(float @ReadOnly [] a1, float @ReadOnly [] a2) { throw new RuntimeException("skeleton method"); }
  public static boolean equals(@ReadOnly Object @ReadOnly [] a1, @ReadOnly Object @ReadOnly [] a2) { throw new RuntimeException("skeleton method"); }
  public static void fill(long @Mutable [] a1, long a2) { throw new RuntimeException("skeleton method"); }
  public static void fill(long @Mutable [] a1, int a2, int a3, long a4) { throw new RuntimeException("skeleton method"); }
  public static void fill(int @Mutable [] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static void fill(int @Mutable [] a1, int a2, int a3, int a4) { throw new RuntimeException("skeleton method"); }
  public static void fill(short @Mutable [] a1, short a2) { throw new RuntimeException("skeleton method"); }
  public static void fill(short @Mutable [] a1, int a2, int a3, short a4) { throw new RuntimeException("skeleton method"); }
  public static void fill(char @Mutable [] a1, char a2) { throw new RuntimeException("skeleton method"); }
  public static void fill(char @Mutable [] a1, int a2, int a3, char a4) { throw new RuntimeException("skeleton method"); }
  public static void fill(byte @Mutable [] a1, byte a2) { throw new RuntimeException("skeleton method"); }
  public static void fill(byte @Mutable [] a1, int a2, int a3, byte a4) { throw new RuntimeException("skeleton method"); }
  public static void fill(boolean @Mutable [] a1, boolean a2) { throw new RuntimeException("skeleton method"); }
  public static void fill(boolean @Mutable [] a1, int a2, int a3, boolean a4) { throw new RuntimeException("skeleton method"); }
  public static void fill(double @Mutable [] a1, double a2) { throw new RuntimeException("skeleton method"); }
  public static void fill(double @Mutable [] a1, int a2, int a3, double a4) { throw new RuntimeException("skeleton method"); }
  public static void fill(float @Mutable [] a1, float a2) { throw new RuntimeException("skeleton method"); }
  public static void fill(float @Mutable [] a1, int a2, int a3, float a4) { throw new RuntimeException("skeleton method"); }
  public static void fill(@I Object @Mutable [] a1, @I Object a2) { throw new RuntimeException("skeleton method"); }
  public static void fill(@I Object @Mutable [] a1, int a2, int a3, @I Object a4) { throw new RuntimeException("skeleton method"); }
  public static <T> T[] copyOf(T[] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static <T, U> T[] copyOf(U[] a1, int a2, Class<? extends T[]> a3) { throw new RuntimeException("skeleton method"); }
  public static byte[] copyOf(byte @ReadOnly [] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static short[] copyOf(short @ReadOnly [] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static int[] copyOf(int @ReadOnly [] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static long[] copyOf(long @ReadOnly [] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static char[] copyOf(char @ReadOnly [] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static float[] copyOf(float @ReadOnly [] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static double[] copyOf(double @ReadOnly [] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static boolean[] copyOf(boolean @ReadOnly [] a1, int a2) { throw new RuntimeException("skeleton method"); }
  public static <T> T[] copyOfRange(T @ReadOnly [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static <T, U> T[] copyOfRange(U @ReadOnly [] a1, int a2, int a3, Class<? extends T[]> a4) { throw new RuntimeException("skeleton method"); }
  public static byte[] copyOfRange(byte @ReadOnly [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static short[] copyOfRange(short @ReadOnly [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static int[] copyOfRange(int @ReadOnly [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static long[] copyOfRange(long @ReadOnly [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static char[] copyOfRange(char @ReadOnly [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static float[] copyOfRange(float @ReadOnly [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static double[] copyOfRange(double @ReadOnly [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  public static boolean[] copyOfRange(boolean @ReadOnly [] a1, int a2, int a3) { throw new RuntimeException("skeleton method"); }
  // In JDK7, should instead be: @SafeVarargs
  @SuppressWarnings({"varargs","unchecked"})
  public static <T> @Mutable List<T> asList(T @ReadOnly ... a1) { throw new RuntimeException("skeleton method"); }
  public static int hashCode(long @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static int hashCode(int @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static int hashCode(short @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static int hashCode(char @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static int hashCode(byte @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static int hashCode(boolean @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static int hashCode(float @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static int hashCode(double @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static int hashCode(@ReadOnly Object @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static int deepHashCode(@ReadOnly Object @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static boolean deepEquals(@ReadOnly Object @ReadOnly [] a1, @ReadOnly Object @ReadOnly [] a2) { throw new RuntimeException("skeleton method"); }
  public static String toString(long @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static String toString(int @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static String toString(short @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static String toString(char @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static String toString(byte @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static String toString(boolean @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static String toString(float @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static String toString(double @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static String toString(@ReadOnly Object @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
  public static String deepToString(@ReadOnly Object @ReadOnly [] a1) { throw new RuntimeException("skeleton method"); }
}
