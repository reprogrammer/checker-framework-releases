package java.util;
import checkers.igj.quals.*;

@I
public class IdentityHashMap<K, V> extends @I AbstractMap<K, V> implements @I Map<K, V>, java.io. @I Serializable, @I Cloneable {
    private static final long serialVersionUID = 0L;
  public IdentityHashMap() { throw new RuntimeException("skeleton method"); }
  public IdentityHashMap(int a1) { throw new RuntimeException("skeleton method"); }
  public IdentityHashMap(@ReadOnly Map<? extends K, ? extends V> a1) { throw new RuntimeException("skeleton method"); }
  public int size(@ReadOnly IdentityHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public boolean isEmpty(@ReadOnly IdentityHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public V get(@ReadOnly IdentityHashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public boolean containsKey(@ReadOnly IdentityHashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public boolean containsValue(@ReadOnly IdentityHashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public V put(@Mutable IdentityHashMap<K, V> this, K a1, V a2) { throw new RuntimeException("skeleton method"); }
  public void putAll(@Mutable IdentityHashMap<K, V> this, @ReadOnly Map<? extends K, ? extends V> a1) { throw new RuntimeException("skeleton method"); }
  public V remove(@Mutable IdentityHashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public void clear(@ReadOnly IdentityHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public boolean equals(@ReadOnly IdentityHashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public int hashCode(@ReadOnly IdentityHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I Set<K> keySet(@ReadOnly IdentityHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I Collection<V> values(@ReadOnly IdentityHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I Set<Map. @I Entry<K, V>> entrySet(@ReadOnly IdentityHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I("N") Object clone() { throw new RuntimeException("skeleton method"); }
}
