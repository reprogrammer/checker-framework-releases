package java.util;

@checkers.igj.quals.I
public interface RandomAccess{
}
