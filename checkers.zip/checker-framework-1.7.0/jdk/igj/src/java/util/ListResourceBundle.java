package java.util;
import checkers.igj.quals.*;

@I
public abstract class ListResourceBundle extends @I ResourceBundle {
  public ListResourceBundle() { throw new RuntimeException("skeleton method"); }
  public final Object  handleGetObject(@ReadOnly ListResourceBundle this, String a1) { throw new RuntimeException("skeleton method"); }
  public Enumeration<String> getKeys(@ReadOnly ListResourceBundle this) { throw new RuntimeException("skeleton method"); }
}
