package java.util;

public class MissingFormatWidthException extends IllegalFormatException {
    private static final long serialVersionUID = 0L;
  public MissingFormatWidthException(String a1) { throw new RuntimeException("skeleton method"); }
  public String getFormatSpecifier() { throw new RuntimeException("skeleton method"); }
  public String getMessage() { throw new RuntimeException("skeleton method"); }
}
