package java.util;

public class MissingResourceException extends RuntimeException {
    private static final long serialVersionUID = 0L;
  public MissingResourceException(String a1, String a2, String a3) { throw new RuntimeException("skeleton method"); }
  public String getClassName() { throw new RuntimeException("skeleton method"); }
  public String getKey() { throw new RuntimeException("skeleton method"); }
}
