package java.util;
import checkers.igj.quals.*;

@I
public class PriorityQueue<E> extends @I AbstractQueue<E> implements java.io. @I Serializable {
    private static final long serialVersionUID = 0L;
  public PriorityQueue() { throw new RuntimeException("skeleton method"); }
  public PriorityQueue(int a1) { throw new RuntimeException("skeleton method"); }
  public PriorityQueue(int a1, @ReadOnly Comparator<? super E> a2) { throw new RuntimeException("skeleton method"); }
  public PriorityQueue(@ReadOnly Collection<? extends E> a1) { throw new RuntimeException("skeleton method"); }
  public PriorityQueue(@ReadOnly PriorityQueue<? extends E> a1) { throw new RuntimeException("skeleton method"); }
  public PriorityQueue(@ReadOnly SortedSet<? extends E> a1) { throw new RuntimeException("skeleton method"); }
  public boolean add(@Mutable PriorityQueue<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public boolean offer(@Mutable PriorityQueue<E> this, E a1) { throw new RuntimeException("skeleton method"); }
  public E peek(@ReadOnly PriorityQueue<E> this) { throw new RuntimeException("skeleton method"); }
  public boolean remove(@Mutable PriorityQueue<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public boolean contains(@ReadOnly PriorityQueue<E> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public Object[] toArray(@ReadOnly PriorityQueue<E> this) { throw new RuntimeException("skeleton method"); }
  public <T> T[] toArray(@ReadOnly PriorityQueue<E> this, T[] a1) { throw new RuntimeException("skeleton method"); }
  public @I Iterator<E> iterator(@ReadOnly PriorityQueue<E> this) { throw new RuntimeException("skeleton method"); }
  public int size(@ReadOnly PriorityQueue<E> this) { throw new RuntimeException("skeleton method"); }
  public void clear(@Mutable PriorityQueue<E> this) { throw new RuntimeException("skeleton method"); }
  public E poll(@Mutable PriorityQueue<E> this) { throw new RuntimeException("skeleton method"); }
  public @ReadOnly Comparator<? super E> comparator(@ReadOnly PriorityQueue<E> this) { throw new RuntimeException("skeleton method"); }
}
