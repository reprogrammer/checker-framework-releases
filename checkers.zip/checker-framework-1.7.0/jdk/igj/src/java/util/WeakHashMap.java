package java.util;
import checkers.igj.quals.*;

@I
public class WeakHashMap<K, V> extends @I AbstractMap<K, V> implements @I Map<K, V> {
  public WeakHashMap(int a1, float a2) { throw new RuntimeException("skeleton method"); }
  public WeakHashMap(int a1) { throw new RuntimeException("skeleton method"); }
  public WeakHashMap() { throw new RuntimeException("skeleton method"); }
  public WeakHashMap(Map<? extends K, ? extends V> a1) { throw new RuntimeException("skeleton method"); }
  public int size(@ReadOnly WeakHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public boolean isEmpty(@ReadOnly WeakHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public V get(@ReadOnly WeakHashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public boolean containsKey(@ReadOnly WeakHashMap<K, V> this, Object a1) { throw new RuntimeException("skeleton method"); }
  public V put(@Mutable WeakHashMap<K, V> this, K a1, V a2) { throw new RuntimeException("skeleton method"); }
  public void putAll(@Mutable WeakHashMap<K, V> this, @ReadOnly Map<? extends K, ? extends V> a1) { throw new RuntimeException("skeleton method"); }
  public V remove(@Mutable WeakHashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public void clear(@Mutable WeakHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public boolean containsValue(@ReadOnly WeakHashMap<K, V> this, Object a1) { throw new RuntimeException("skeleton method"); }
  public @I Set<K> keySet(@ReadOnly WeakHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I Collection<V> values(@ReadOnly WeakHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  public @I Set<Map. @I Entry<K, V>> entrySet(@ReadOnly WeakHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
}
