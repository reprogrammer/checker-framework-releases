package java.util;
import checkers.igj.quals.*;

@I
public class LinkedHashMap<K, V> extends @I HashMap<K, V> implements @I Map<K, V> {
    private static final long serialVersionUID = 0L;
  public LinkedHashMap(int a1, float a2) { throw new RuntimeException("skeleton method"); }
  public LinkedHashMap(int a1) { throw new RuntimeException("skeleton method"); }
  public LinkedHashMap() { throw new RuntimeException("skeleton method"); }
  public LinkedHashMap(@ReadOnly Map<? extends K, ? extends V> a1) { throw new RuntimeException("skeleton method"); }
  public LinkedHashMap(int a1, float a2, boolean a3) { throw new RuntimeException("skeleton method"); }
  public boolean containsValue(@ReadOnly LinkedHashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public V get(@ReadOnly LinkedHashMap<K, V> this, @ReadOnly Object a1) { throw new RuntimeException("skeleton method"); }
  public void clear(@Mutable LinkedHashMap<K, V> this) { throw new RuntimeException("skeleton method"); }
  protected boolean removeEldestEntry(Map.Entry<K, V> entry) { throw new RuntimeException("skeleton method"); }
}
