package java.util;

public class EmptyStackException extends RuntimeException {
    private static final long serialVersionUID = 0L;
  public EmptyStackException() { throw new RuntimeException("skeleton method"); }
}
