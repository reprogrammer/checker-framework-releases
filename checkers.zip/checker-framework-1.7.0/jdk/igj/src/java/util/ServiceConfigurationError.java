package java.util;

public class ServiceConfigurationError extends Error {
    private static final long serialVersionUID = 0L;
  public ServiceConfigurationError(String a1) { throw new RuntimeException("skeleton method"); }
  public ServiceConfigurationError(String a1, Throwable a2) { throw new RuntimeException("skeleton method"); }
}
