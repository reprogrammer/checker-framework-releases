package java.util;

public class NoSuchElementException extends RuntimeException {
    private static final long serialVersionUID = 0L;
  public NoSuchElementException() { throw new RuntimeException("skeleton method"); }
  public NoSuchElementException(String a1) { throw new RuntimeException("skeleton method"); }
}
