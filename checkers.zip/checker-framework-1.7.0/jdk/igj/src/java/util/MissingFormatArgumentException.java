package java.util;

public class MissingFormatArgumentException extends IllegalFormatException {
    private static final long serialVersionUID = 0L;
  public MissingFormatArgumentException(String a1) { throw new RuntimeException("skeleton method"); }
  public String getFormatSpecifier() { throw new RuntimeException("skeleton method"); }
  public String getMessage() { throw new RuntimeException("skeleton method"); }
}
