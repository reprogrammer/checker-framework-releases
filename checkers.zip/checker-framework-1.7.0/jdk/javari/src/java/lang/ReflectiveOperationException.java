package java.lang;

public class ReflectiveOperationException extends Exception {
    static final long serialVersionUID = 123456789L;

    public ReflectiveOperationException() {
        throw new RuntimeException("skeleton method");
    }

    public ReflectiveOperationException(String message) {
        throw new RuntimeException("skeleton method");
    }

    public ReflectiveOperationException(Throwable cause) {
        throw new RuntimeException("skeleton method");
    }
}
