package java.lang;
import checkers.javari.quals.*;

public class UnsupportedOperationException extends RuntimeException {
    public UnsupportedOperationException() {
        throw new RuntimeException("skeleton method");
    }

    public UnsupportedOperationException(String message) {
        throw new RuntimeException("skeleton method");
    }

    public UnsupportedOperationException(String message, Throwable cause) {
        throw new RuntimeException("skeleton method");
    }

    public UnsupportedOperationException(Throwable cause) {
        throw new RuntimeException("skeleton method");
    }

    static final long serialVersionUID = -1242599979055084673L;
}
