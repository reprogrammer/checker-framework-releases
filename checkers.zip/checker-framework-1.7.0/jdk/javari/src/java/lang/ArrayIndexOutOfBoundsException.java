package java.lang;
import checkers.javari.quals.*;

public class ArrayIndexOutOfBoundsException extends IndexOutOfBoundsException {
    private static final long serialVersionUID = -5116101128118950844L;

    public ArrayIndexOutOfBoundsException() {
        throw new RuntimeException("skeleton method");
    }

    public ArrayIndexOutOfBoundsException(int index) {
        throw new RuntimeException("skeleton method");
    }

    public ArrayIndexOutOfBoundsException(String s) {
        throw new RuntimeException("skeleton method");
    }
}
