package java.lang;
import checkers.javari.quals.*;

public class ClassNotFoundException extends Exception {
    private static final long serialVersionUID = 0L;
    public ClassNotFoundException() {
        throw new RuntimeException("skeleton method");
    }

    public ClassNotFoundException(String s) {
        throw new RuntimeException("skeleton method");
    }

    public ClassNotFoundException(String s, Throwable exception) {
        throw new RuntimeException("skeleton method");
    }

    public Throwable getCause() {
        throw new RuntimeException("skeleton method");
    }

    public Throwable getException() {
        throw new RuntimeException("skeleton method");
    }

}
