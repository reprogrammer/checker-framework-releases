package java.lang;
import checkers.javari.quals.*;

public class Exception extends Throwable {
    static final long serialVersionUID = -3387516993124229948L;

    public Exception() {
        throw new RuntimeException("skeleton method");
    }

    public Exception(String message) {
        throw new RuntimeException("skeleton method");
    }

    public Exception(String message, Throwable cause) {
        throw new RuntimeException("skeleton method");
    }

    public Exception(Throwable cause) {
        throw new RuntimeException("skeleton method");
    }
}
