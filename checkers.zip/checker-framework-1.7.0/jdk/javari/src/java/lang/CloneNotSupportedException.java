package java.lang;
import checkers.javari.quals.*;

public class CloneNotSupportedException extends Exception {
    private static final long serialVersionUID = 0L;
    public CloneNotSupportedException() {
        throw new RuntimeException("skeleton method");
    }

    public CloneNotSupportedException(String s) {
        throw new RuntimeException("skeleton method");
    }
}
