package java.lang;
import checkers.javari.quals.*;

public class AssertionError extends Error {
    private static final long serialVersionUID = 0L;
    public AssertionError() {
        throw new RuntimeException("skeleton method");
    }

    private AssertionError(String detailMessage) {
        throw new RuntimeException("skeleton method");
    }

    public AssertionError(Object detailMessage) {
        throw new RuntimeException("skeleton method");
    }

    public AssertionError(boolean detailMessage) {
        throw new RuntimeException("skeleton method");
    }

    public AssertionError(char detailMessage) {
        throw new RuntimeException("skeleton method");
    }

    public AssertionError(int detailMessage) {
        throw new RuntimeException("skeleton method");
    }

    public AssertionError(long detailMessage) {
        throw new RuntimeException("skeleton method");
    }

    public AssertionError(float detailMessage) {
        throw new RuntimeException("skeleton method");
    }

    public AssertionError(double detailMessage) {
        throw new RuntimeException("skeleton method");
    }
}
