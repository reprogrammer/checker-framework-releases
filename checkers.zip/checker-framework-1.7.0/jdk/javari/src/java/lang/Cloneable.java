package java.lang;
import checkers.javari.quals.*;

public interface Cloneable {}
