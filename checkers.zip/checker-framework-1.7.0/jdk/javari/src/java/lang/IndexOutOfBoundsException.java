package java.lang;
import checkers.javari.quals.*;

public class IndexOutOfBoundsException extends RuntimeException {
    private static final long serialVersionUID = 234122996006267687L;

    public IndexOutOfBoundsException() {
        throw new RuntimeException("skeleton method");
    }

    public IndexOutOfBoundsException(String s) {
        throw new RuntimeException("skeleton method");
    }
}
