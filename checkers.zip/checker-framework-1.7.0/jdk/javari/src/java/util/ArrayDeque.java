package java.util;
import checkers.javari.quals.*;

public class ArrayDeque<E> extends AbstractCollection<E> implements Deque<E>, Cloneable, java.io.Serializable {
    private static final long serialVersionUID = 0L;
  public ArrayDeque() { throw new RuntimeException(("skeleton method")); }
  public ArrayDeque(int a1) { throw new RuntimeException(("skeleton method")); }
  public @PolyRead ArrayDeque(@PolyRead Collection<? extends E> a1) { throw new RuntimeException(("skeleton method")); }
  public void addFirst(E a1) { throw new RuntimeException(("skeleton method")); }
  public void addLast(E a1) { throw new RuntimeException(("skeleton method")); }
  public boolean offerFirst(E a1) { throw new RuntimeException(("skeleton method")); }
  public boolean offerLast(E a1) { throw new RuntimeException(("skeleton method")); }
  public E removeFirst() { throw new RuntimeException(("skeleton method")); }
  public E removeLast() { throw new RuntimeException(("skeleton method")); }
  public E pollFirst() { throw new RuntimeException(("skeleton method")); }
  public E pollLast() { throw new RuntimeException(("skeleton method")); }
  public E getFirst() { throw new RuntimeException(("skeleton method")); }
  public E getLast() { throw new RuntimeException(("skeleton method")); }
  public E peekFirst(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException(("skeleton method")); }
  public E peekLast(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException(("skeleton method")); }
  public boolean removeFirstOccurrence(@ReadOnly Object a1) { throw new RuntimeException(("skeleton method")); }
  public boolean removeLastOccurrence(@ReadOnly Object a1) { throw new RuntimeException(("skeleton method")); }
  public boolean add(E a1) { throw new RuntimeException(("skeleton method")); }
  public boolean offer(E a1) { throw new RuntimeException(("skeleton method")); }
  public E remove() { throw new RuntimeException(("skeleton method")); }
  public E poll() { throw new RuntimeException(("skeleton method")); }
  public E element(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException(("skeleton method")); }
  public E peek(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException(("skeleton method")); }
  public void push(E a1) { throw new RuntimeException(("skeleton method")); }
  public E pop() { throw new RuntimeException(("skeleton method")); }
  public int size(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException(("skeleton method")); }
  public boolean isEmpty(@ReadOnly ArrayDeque<E> this) { throw new RuntimeException(("skeleton method")); }
  public @PolyRead Iterator<E> iterator(@PolyRead ArrayDeque<E> this) { throw new RuntimeException(("skeleton method")); }
  public @PolyRead Iterator<E> descendingIterator(@PolyRead ArrayDeque<E> this) { throw new RuntimeException(("skeleton method")); }
  public boolean contains(@ReadOnly ArrayDeque<E> this, @ReadOnly Object a1) { throw new RuntimeException(("skeleton method")); }
  public boolean remove(@ReadOnly ArrayDeque<E> this, @ReadOnly Object a1) { throw new RuntimeException(("skeleton method")); }
  public void clear() { throw new RuntimeException(("skeleton method")); }
  public Object[] toArray() { throw new RuntimeException(("skeleton method")); }
  public <T> T[] toArray(T[] a1) { throw new RuntimeException(("skeleton method")); }
  public ArrayDeque<E> clone() { throw new RuntimeException("skeleton method"); }
}
