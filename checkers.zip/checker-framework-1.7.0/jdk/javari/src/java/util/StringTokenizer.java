package java.util;
import checkers.javari.quals.*;

public class StringTokenizer implements Enumeration<Object> {
  public StringTokenizer(String a1, String a2, boolean a3) { throw new RuntimeException(("skeleton method")); }
  public StringTokenizer(String a1, String a2) { throw new RuntimeException(("skeleton method")); }
  public StringTokenizer(String a1) { throw new RuntimeException(("skeleton method")); }
  public boolean hasMoreTokens(@ReadOnly StringTokenizer this) { throw new RuntimeException(("skeleton method")); }
  public @PolyRead String nextToken(@PolyRead StringTokenizer this) { throw new RuntimeException(("skeleton method")); }
  public @PolyRead String nextToken(@PolyRead StringTokenizer this, String a1) { throw new RuntimeException(("skeleton method")); }
  public boolean hasMoreElements(@ReadOnly StringTokenizer this) { throw new RuntimeException(("skeleton method")); }
  public @PolyRead Object nextElement(@PolyRead StringTokenizer this) { throw new RuntimeException(("skeleton method")); }
  public int countTokens(@ReadOnly StringTokenizer this) { throw new RuntimeException(("skeleton method")); }
}
