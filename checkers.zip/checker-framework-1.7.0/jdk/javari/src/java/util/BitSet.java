package java.util;
import checkers.javari.quals.*;

public class BitSet implements Cloneable, java.io.Serializable {
    private static final long serialVersionUID = 0L;
  public BitSet() { throw new RuntimeException(("skeleton method")); }
  public BitSet(int a1) { throw new RuntimeException(("skeleton method")); }
  public void flip(int a1) { throw new RuntimeException(("skeleton method")); }
  public void flip(int a1, int a2) { throw new RuntimeException(("skeleton method")); }
  public void set(int a1) { throw new RuntimeException(("skeleton method")); }
  public void set(int a1, boolean a2) { throw new RuntimeException(("skeleton method")); }
  public void set(int a1, int a2) { throw new RuntimeException(("skeleton method")); }
  public void set(int a1, int a2, boolean a3) { throw new RuntimeException(("skeleton method")); }
  public void clear(int a1) { throw new RuntimeException(("skeleton method")); }
  public void clear(int a1, int a2) { throw new RuntimeException(("skeleton method")); }
  public void clear() { throw new RuntimeException(("skeleton method")); }
  public boolean get(@ReadOnly BitSet this, int a1) { throw new RuntimeException(("skeleton method")); }
  public BitSet get(@ReadOnly BitSet this, int a1, int a2) { throw new RuntimeException(("skeleton method")); }
  public int nextSetBit(@ReadOnly BitSet this, int a1) { throw new RuntimeException(("skeleton method")); }
  public int nextClearBit(@ReadOnly BitSet this, int a1) { throw new RuntimeException(("skeleton method")); }
  public int length(@ReadOnly BitSet this) { throw new RuntimeException(("skeleton method")); }
  public boolean isEmpty(@ReadOnly BitSet this) { throw new RuntimeException(("skeleton method")); }
  public boolean intersects(@ReadOnly BitSet this, BitSet a1) { throw new RuntimeException(("skeleton method")); }
  public int cardinality(@ReadOnly BitSet this) { throw new RuntimeException(("skeleton method")); }
  public void and(@ReadOnly BitSet a1) { throw new RuntimeException(("skeleton method")); }
  public void or(@ReadOnly BitSet a1) { throw new RuntimeException(("skeleton method")); }
  public void xor(@ReadOnly BitSet a1) { throw new RuntimeException(("skeleton method")); }
  public void andNot(@ReadOnly BitSet a1) { throw new RuntimeException(("skeleton method")); }
  public int hashCode(@ReadOnly BitSet this){ throw new RuntimeException(("skeleton method")); }
  public int size(@ReadOnly BitSet this) { throw new RuntimeException(("skeleton method")); }
  public boolean equals(@ReadOnly BitSet this, @ReadOnly Object a1) { throw new RuntimeException(("skeleton method")); }
  public Object clone(@ReadOnly BitSet this) { throw new RuntimeException(("skeleton method")); }
  public String toString(@ReadOnly BitSet this){ throw new RuntimeException(("skeleton method")); }
}
