package java.util;
import checkers.javari.quals.*;

public interface RandomAccess {}
