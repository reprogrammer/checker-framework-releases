package java.util;
import checkers.javari.quals.*;

public class LinkedHashSet<E> extends HashSet<E> implements Set<E>, Cloneable, java.io.Serializable {
    private static final long serialVersionUID = 0L;
    public LinkedHashSet(int initialCapacity, float loadFactor) { throw new RuntimeException("skeleton method"); }
    public LinkedHashSet(int initialCapacity) { throw new RuntimeException("skeleton method"); }
    public LinkedHashSet() { throw new RuntimeException("skeleton method"); }
    public LinkedHashSet(@ReadOnly Collection<? extends E> c) { throw new RuntimeException("skeleton method"); }
}
