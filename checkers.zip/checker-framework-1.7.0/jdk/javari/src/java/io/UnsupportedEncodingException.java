package java.io;
import checkers.javari.quals.*;

public class UnsupportedEncodingException extends IOException {
    private static final long serialVersionUID = -4274276298326136670L;

    public UnsupportedEncodingException() {
        throw new RuntimeException("skeleton method");
    }

    public UnsupportedEncodingException(String s) {
        throw new RuntimeException("skeleton method");
    }
}
