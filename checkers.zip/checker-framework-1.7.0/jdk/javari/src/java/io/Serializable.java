package java.io;
import checkers.javari.quals.*;

public interface Serializable {}
