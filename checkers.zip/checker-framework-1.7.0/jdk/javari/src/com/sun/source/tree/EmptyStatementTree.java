package com.sun.source.tree;
import checkers.javari.quals.*;

public interface EmptyStatementTree extends StatementTree {}
