package com.sun.source.tree;
import checkers.javari.quals.*;

public interface StatementTree extends Tree {}
