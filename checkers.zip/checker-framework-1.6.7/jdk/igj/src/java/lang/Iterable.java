package java.lang;
import checkers.igj.quals.*;

@I
public interface Iterable<T> {
    public abstract java.util. @I Iterator<T> iterator(@ReadOnly Iterable<T> this);
}
